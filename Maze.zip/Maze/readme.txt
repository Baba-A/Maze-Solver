//ABUBAKAR BABA AWUMBILA
//IMPLEMENTATION OF THE 'RIGHT-HAND RULE' MAZE SOLVING ALGORITHM - Readme


To Compile and run this program:

1. Open the Terminal application in Mac OSX or the Command Prompt Application in windows.

2. Navigate into the directory with all the files ( The directory with the read-me file) using the cd (change directory) command.

3.Compile the program with the following command : g++ Maze.cpp MazeApp.cpp -o maze

  You can also compile the program using the makefile with the following command : make

4. Run the executable file with the following command : ./maze




Thanks for taking the time to view this project.



